const express = require('express');
const router = express.Router();

const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');

const User = require('../models/User');

// EMAIL TRANSPORTER
const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
    }
});


// ========================
// SEND OTP
// ========================
router.post('/send-otp', async (req, res) => {
    const { email } = req.body;

    const otp = Math.floor(100000 + Math.random() * 900000).toString();

    let user = await User.findOne({ email });

    if (!user) {
        user = new User({ email, otp });
    } else {
        user.otp = otp;
    }

    await user.save();

    await transporter.sendMail({
        from: process.env.EMAIL_USER,
        to: email,
        subject: "DTR System OTP Verification",
        text: `Your OTP is ${otp}`
    });

    res.json({ message: "OTP sent successfully" });
});


// ========================
// VERIFY OTP
// ========================
router.post('/verify-otp', async (req, res) => {
    const { email, otp } = req.body;

    const user = await User.findOne({ email });

    if (!user) {
        return res.status(400).json({ message: "User not found" });
    }

    if (user.otp !== otp) {
        return res.status(400).json({ message: "Invalid OTP" });
    }

    user.verified = true;
    await user.save();

    res.json({ message: "OTP verified" });
});


// ========================
// REGISTER USER
// ========================
router.post('/register', async (req, res) => {
    const { name, email, password } = req.body;

    const user = await User.findOne({ email });

    if (!user || !user.verified) {
        return res.status(400).json({ message: "OTP not verified" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    user.name = name;
    user.password = hashedPassword;

    await user.save();

    res.json({ message: "User registered successfully" });
});


// ========================
// LOGIN
// ========================
router.post('/login', async (req, res) => {
    const { email, password } = req.body;

    // ADMIN LOGIN (fixed account)
    if (email === "Administrator" && password === "Password") {
        return res.json({
            role: "admin",
            token: "ADMIN_TOKEN"
        });
    }

    const user = await User.findOne({ email });

    if (!user) {
        return res.status(400).json({ message: "User not found" });
    }

    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
        return res.status(400).json({ message: "Wrong password" });
    }

    const token = jwt.sign(
        { id: user._id },
        process.env.JWT_SECRET,
        { expiresIn: "1d" }
    );

    res.json({
        role: "staff",
        token,
        name: user.name
    });
});

module.exports = router;
