const express = require('express');
const router = express.Router();

const Attendance = require('../models/Attendance');


// ========================
// ESP32 SEND ATTENDANCE
// ========================
router.post('/log', async (req, res) => {
    const { employee, date, time, status } = req.body;

    try {
        const newLog = new Attendance({
            employee,
            date,
            time,
            status
        });

        await newLog.save();

        res.json({ message: "Attendance saved successfully" });

    } catch (err) {
        res.status(500).json({ message: "Error saving attendance" });
    }
});


// ========================
// GET ALL ATTENDANCE (ADMIN)
// ========================
router.get('/all', async (req, res) => {
    try {
        const logs = await Attendance.find().sort({ _id: -1 });
        res.json(logs);
    } catch (err) {
        res.status(500).json({ message: "Error fetching data" });
    }
});

module.exports = router;
